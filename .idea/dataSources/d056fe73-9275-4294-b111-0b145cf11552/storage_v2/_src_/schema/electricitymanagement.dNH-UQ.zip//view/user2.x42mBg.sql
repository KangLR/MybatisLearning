create view user2 as
select `electricitymanagement`.`user`.`user_name`                                                               AS `user_name`,
       `electricitymanagement`.`user`.`telephone`                                                               AS `telephone`,
       `electricitymanagement`.`user`.`email`                                                                   AS `email`,
       `electricitymanagement`.`establish`.`order_number`                                                       AS `order_number`,
       `electricitymanagement`.`order_table`.`order_state`                                                      AS `order_state`,
       `electricitymanagement`.`product`.`product_name`                                                         AS `product_name`,
       `electricitymanagement`.`product`.`product_description`                                                  AS `product_description`,
       (`electricitymanagement`.`product`.`product_price` *
        `electricitymanagement`.`order_include`.`quantity`)                                                     AS `total_price`
from ((((`electricitymanagement`.`user` join `electricitymanagement`.`establish` on ((
        `electricitymanagement`.`user`.`user_name` =
        `electricitymanagement`.`establish`.`user_name`))) join `electricitymanagement`.`order_table` on ((
        `electricitymanagement`.`establish`.`order_number` =
        `electricitymanagement`.`order_table`.`order_number`))) join `electricitymanagement`.`order_include` on ((
        `electricitymanagement`.`order_table`.`order_number` = `electricitymanagement`.`order_include`.`order_number`)))
         join `electricitymanagement`.`product` on ((`electricitymanagement`.`order_include`.`product_number` =
                                                     `electricitymanagement`.`product`.`product_number`)))
where (`electricitymanagement`.`user`.`user_name` = 'user2')
order by `electricitymanagement`.`establish`.`order_number`,
         (`electricitymanagement`.`product`.`product_price` * `electricitymanagement`.`order_include`.`quantity`);

